#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <signal.h>
#include <syscall.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/reg.h>
#include <sys/user.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h>

#include "elf64.h"

#define	ET_NONE	0	//No file type 
#define	ET_REL	1	//Relocatable file 
#define	ET_EXEC	2	//Executable file 
#define	ET_DYN	3	//Shared object file 
#define	ET_CORE	4	//Core file 

#define SHT_SYMTAB (0x2)
#define SHT_STRTAB (0x3)

#define SYM_GLOBAL (0x01)
#define SYM_LOCAL (0x00)

bool checkNameInFile(char *name, FILE *file, long offset) {
    size_t nameLen = strlen(name) + 1;
    fseek(file, offset, SEEK_SET);
    char *symName = (char*)malloc(nameLen);
    fread(symName, nameLen, 1, file);

    //printf("name in offset %lu is: %s\n", offset, symName);

    bool isSimilar = (0 == strncmp(name, symName, nameLen));
    free(symName);

    return isSimilar;
}


/* symbol_name		- The symbol (maybe function) we need to search for.
 * exe_file_name	- The file where we search the symbol in.
 * error_val		- If  1: A global symbol was found, and defined in the given executable.
 * 			- If -1: Symbol not found.
 *			- If -2: Only a local symbol was found.
 * 			- If -3: File is not an executable.
 * 			- If -4: The symbol was found, it is global, but it is not defined in the executable.
 * return value		- The address which the symbol_name will be loaded to, if the symbol was found and is global.
 */
unsigned long find_symbol(char* symbol_name, char* exe_file_name, int* error_val) {
	// Open file
    FILE *elfFile = fopen(exe_file_name, "r");
    


    // Parse Elf Header
    Elf64_Ehdr elfHeader = {0};
    fread(&elfHeader, sizeof(elfHeader), 1 , elfFile);

    if (elfHeader.e_type != ET_EXEC) {
        //printf("NOT EXE\n");
        *error_val = -3;
        fclose(elfFile);
        return -3;
    }
    
    
    // Find Section header table
    Elf64_Off sectionHeaderOffset = elfHeader.e_shoff;
    //printf("section header offset: %lx\n", sectionHeaderOffset);
    Elf64_Half sectionHeaderLen = elfHeader.e_shnum;
    Elf64_Half sectionHeadeEntrySize = elfHeader.e_shentsize;
    Elf64_Shdr *sectionHeaderTable = (Elf64_Shdr *)calloc(sectionHeaderLen, sectionHeadeEntrySize);
    fseek(elfFile, sectionHeaderOffset, SEEK_SET);
    fread(sectionHeaderTable, sectionHeadeEntrySize, sectionHeaderLen, elfFile);

    // Find symbol header table
    Elf64_Shdr *curr = sectionHeaderTable;
    int i = 0;
    for (i = 0; i < sectionHeaderLen; i++) {
        if (curr->sh_type == SHT_SYMTAB && checkNameInFile(".symtab", elfFile, sectionHeaderTable[elfHeader.e_shstrndx].sh_offset + curr->sh_name)) {
            break;
        }
        curr = (Elf64_Shdr *)((char *)curr + sectionHeadeEntrySize);
    }

    if (i == sectionHeaderLen) {
        free(sectionHeaderTable);
        fclose(elfFile);
        return -1;
    }

    // Found section table entry of the symbol table
    Elf64_Off symTabOffset = curr->sh_offset;
    Elf64_Xword symTabSize = curr->sh_size;
    Elf64_Xword symTabEntSize = curr->sh_entsize;
    Elf64_Sym *symTab = (Elf64_Sym *)malloc(symTabSize);
    fseek(elfFile, symTabOffset, SEEK_SET);
    fread(symTab, symTabSize, 1, elfFile);


    // Get string Table
    curr = sectionHeaderTable;
    int j = 0;
    for (j = 0; j < sectionHeaderLen; j++) {
        if (curr->sh_type == SHT_STRTAB && checkNameInFile(".strtab", elfFile, sectionHeaderTable[elfHeader.e_shstrndx].sh_offset + curr->sh_name)) {

            //printf("FOUND str tab: %lx\n", curr->sh_offset);
            break;
        }
        curr = (Elf64_Shdr *)((char *)curr + sectionHeadeEntrySize);
    }

    
    if (j == sectionHeaderLen) {
        //printf("DIDN'T FIND STR TABLE\n");
        free(sectionHeaderTable);
        free(symTab);
        fclose(elfFile);
        return -1;
    }

    Elf64_Off strTabOffset = curr->sh_offset;
    
    // Look for the symbol in the table
    Elf64_Sym *wantedSymbolEnt = symTab;
    int symTabLen = symTabSize / symTabEntSize;
    int k =0;
    bool foundLocal = false;
    for (k = 0; k < symTabLen ; k++) {
        if (checkNameInFile(symbol_name, elfFile, strTabOffset + wantedSymbolEnt->st_name)) {
            // Found symbol <confetti>, check if dymanic
            if (ELF64_ST_BIND(wantedSymbolEnt->st_info) == SYM_GLOBAL) {
                // Check if in this file or not
                if (wantedSymbolEnt->st_shndx == 0) {
                    free(symTab);
                    free(sectionHeaderTable);
                    fclose(elfFile);
                    *error_val = -4;
                    return -4;
                } else {
                    // FOUND
                    *error_val = 1;
                    free(symTab);
                    free(sectionHeaderTable);
                    fclose(elfFile);
                    return wantedSymbolEnt->st_value;
                }
            } else {
                foundLocal = true;
            }
        }

        wantedSymbolEnt = (Elf64_Sym *)(((char*)wantedSymbolEnt) + symTabEntSize);
    }

    if (k == symTabLen) {
        if (foundLocal) {
            *error_val = -2;
            free(symTab);
            free(sectionHeaderTable);
            fclose(elfFile);
            return -2;
        } else {
            //printf("Didn't find sym in sym tab entry"); 
            *error_val = -1;
            free(symTab);
            free(sectionHeaderTable);
            fclose(elfFile);
            return -1;
        }
    }
 

    // Check if symbol is global or dynamic

    // Close file
    fclose(elfFile);
    free(symTab);
    free(sectionHeaderTable);
	return 0;
}

int main(int argc, char *const argv[]) {
	int err = 0;
	unsigned long addr = find_symbol(argv[1], argv[2], &err);

	if (err >= 0)
		printf("%s will be loaded to 0x%lx\n", argv[1], addr);
	else if (err == -2)
		printf("%s is not a global symbol! :(\n", argv[1]);
	else if (err == -1)
		printf("%s not found!\n", argv[1]);
	else if (err == -3)
		printf("%s not an executable! :(\n", argv[2]);
	else if (err == -4)
		printf("%s is a global symbol, but will come from a shared library\n", argv[1]);
	return 0;
}